#include <iostream>
#include <string.h>
#include <fstream>
#include <cerrno>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#define PORT 4444

using namespace std;

int main() {
  int serSockDes, readStatus,len;
  struct sockaddr_in serAddr, cliAddr;
   //int len = sizeof(struct sockaddr_in);
  char sbuff[1024] = {0};
    char msg[] = "Broadcast message from READER\n";
  int broadcast = 1;
 // cout<<"creating a new server socket\n";
  if((serSockDes = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    perror("socket creation error...\n");
    exit(-1);
  }
  // cout<<"server socket created\n";
   
   
   if(setsockopt(serSockDes, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast)) <0)
   {
   
    perror("socket set error...\n");
    exit(-1);
   }
   
   
  //cout<<"binding the port to ip and port";
  serAddr.sin_family = AF_INET;
  serAddr.sin_port = htons(PORT);
  serAddr.sin_addr.s_addr = INADDR_ANY;

  if((bind(serSockDes, (struct sockaddr*)&serAddr, sizeof(serAddr))) < 0) {
    perror("binding error...\n");
    exit(-1);
  }
//cout<<"binding the port to ip and port";
//cout<<"receving data from client";
  readStatus = recvfrom(serSockDes, sbuff, 1024, 0, (struct sockaddr*)&cliAddr,(socklen_t*)&len);
  sbuff[readStatus] = '\0';
  cout<<sbuff;

  cout<<len;
//cout<<"sending reply from server";
  if(sendto(serSockDes, msg, strlen(msg)+1, 0, (struct sockaddr*)&cliAddr, sizeof(struct sockaddr_in))==-1)
  //int sed=sendto(serSockDes, msg, strlen(msg)+1, 0, (struct sockaddr*)&cliAddr, sizeof(struct sockaddr_in));
  //cout<<msg[sed];
   cout << " Value of errno is : " << errno << '\n';
  //cout <<"msg send from server\n";

  return 0;
}
